package hybrid;

public class Hybrid {

}
