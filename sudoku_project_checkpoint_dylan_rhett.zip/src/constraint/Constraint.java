package constraint;

public class Constraint {

}
